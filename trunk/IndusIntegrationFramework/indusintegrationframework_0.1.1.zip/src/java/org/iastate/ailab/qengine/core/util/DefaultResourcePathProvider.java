package org.iastate.ailab.qengine.core.util;

public class DefaultResourcePathProvider {
}
