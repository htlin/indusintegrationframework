package org.iastate.ailab.qengine.core.exceptions;

public class UnknownAVHRoleException extends IllegalArgumentException {

   private static final long serialVersionUID = 1L;

}
