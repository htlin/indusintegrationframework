package org.iastate.ailab.qengine.core.convertors;

public interface DataConvertor {

}
