package org.iastate.ailab.qengine.core.util;

import org.iastate.ailab.qengine.core.datasource.DataNode;

public interface DataSourceDescriptorLoader {
   public void addDataSourceDescriptors(DataNode node);
}
