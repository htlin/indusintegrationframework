package org.iastate.ailab.qengine.core.util;

public class Test {
   
   public Test() {
      
   }

   public static void sayHello() {
      System.out.println("hello");
   }
   
   public void echo (String s) {
      System.out.println(s);
   }
}
