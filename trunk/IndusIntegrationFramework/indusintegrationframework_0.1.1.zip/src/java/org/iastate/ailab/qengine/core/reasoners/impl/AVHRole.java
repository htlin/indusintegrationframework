package org.iastate.ailab.qengine.core.reasoners.impl;

public enum AVHRole {
   SUB_CLASS, SUPER_CLASS, EQUIVALENT_CLASS
}