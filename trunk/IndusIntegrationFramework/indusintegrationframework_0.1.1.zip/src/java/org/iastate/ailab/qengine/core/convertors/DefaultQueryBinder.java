package org.iastate.ailab.qengine.core.convertors;

import Zql.ZQuery;

public class DefaultQueryBinder implements QueryBinder {
   public ZQuery bind(ZQuery query, String dataSource) {
      return null;
   }
}
