package org.iastate.ailab.qengine.core.util;

public interface ResourcePathProvider {
}
